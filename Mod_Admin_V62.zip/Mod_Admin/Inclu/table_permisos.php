<?php

print("<table align='center' style=\"margin-top:200px;margin-bottom:200px\">
						<tr align='center'>
							<td>
								<font color='red'>
									<b>
										ACCESO RESTRINGIDO.
									</br>
										CONSULTE SUS PERMISOS ADMINISTRATIVOS.
									</b>
								</font>
							</td>
						</tr>
					</table>");

?>