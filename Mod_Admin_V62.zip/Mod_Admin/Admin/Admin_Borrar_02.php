<?php
session_start();

	require '../Inclu/error_hidden.php';
	require '../Inclu/Admin_head.php';
	require '../Inclu/webmaster.php';
	require '../Conections/conection.php';
	require '../Conections/conect.php';

	require 'Admin_Borrar_02_Funciones.php';

	require 'Admin_Borrar_02_Logica.php';

	require '../Inclu/Admin_Inclu_footer.php';

				   ////////////////////				   ////////////////////
////////////////////				////////////////////				////////////////////
				 ////////////////////				  ///////////////////

/* Creado por Juan Barros Pazos 2021 */
?>
