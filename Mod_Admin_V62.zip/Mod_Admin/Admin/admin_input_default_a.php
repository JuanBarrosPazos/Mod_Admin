<?php

     print("<input type='hidden' name='id' value='".$defaults['id']."' />					
            <input type='hidden' name='ref' value='".$defaults['ref']."' />					
            <input type='hidden' name='Nombre' value='".$defaults['Nombre']."' />
            <input type='hidden' name='Apellidos' value='".$defaults['Apellidos']."' />
            <input type='hidden' name='myimg' value='".$_POST['myimg']."' />
            <input type='hidden' name='doc' value='".$defaults['doc']."' />
            <input type='hidden' name='dni' value='".$defaults['dni']."' />
            <input type='hidden' name='ldni' value='".$defaults['ldni']."' />
            <input type='hidden' name='Email' value='".$defaults['Email']."' />
            <input type='hidden' name='Usuario' value='".$defaults['Usuario']."' />
            <input type='hidden' name='Password' value='".$defaults['Password']."' />
            <input type='hidden' name='Pass' value='".$defaults['Pass']."' />
            <input type='hidden' name='Nivel' value='".$defaults['Nivel']."' />
            <input type='hidden' name='Direccion' value='".$defaults['Direccion']."' />
            <input type='hidden' name='Tlf1' value='".$defaults['Tlf1']."' />
            <input type='hidden' name='Tlf2' value='".$defaults['Tlf2']."' />
            <input type='hidden' name='lastin' value='".$defaults['lastin']."' />					
            <input type='hidden' name='lastout' value='".$defaults['lastout']."' />					
            <input type='hidden' name='visitadmin' value='".$defaults['visitadmin']."' />
            <input type='hidden' name='borrado' value='".$defaults['borrado']."' />");

?>