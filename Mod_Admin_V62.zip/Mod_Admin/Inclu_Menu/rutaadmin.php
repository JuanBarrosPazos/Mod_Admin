<?php

    global $rutaindex;
    $rutaindex = '../';
    global $rutaadmin;
    $rutaadmin = '';
    global $rutabbdd;
    $rutabbdd = $rutaindex.'upbbdd/';
    global $rutacam;
    $rutacam = $rutaindex.'cam/';
    global $rutaqrgen;
    $rutaqrgen = $rutaindex.'qrgen/';
    global $rutainclu;
    $rutainclu = $rutaindex.'Inclu/';

    global $rutaOut;
    $rutaOut = $rutaindex.'../';

?>